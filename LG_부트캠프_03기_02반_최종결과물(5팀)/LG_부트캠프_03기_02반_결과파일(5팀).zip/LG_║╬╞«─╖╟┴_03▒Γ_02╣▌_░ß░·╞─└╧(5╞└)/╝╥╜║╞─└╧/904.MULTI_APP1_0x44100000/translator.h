

void translation(char* res, char* input, int type);
int asciiToInt(char input);
void initCharPointer(char* input);
