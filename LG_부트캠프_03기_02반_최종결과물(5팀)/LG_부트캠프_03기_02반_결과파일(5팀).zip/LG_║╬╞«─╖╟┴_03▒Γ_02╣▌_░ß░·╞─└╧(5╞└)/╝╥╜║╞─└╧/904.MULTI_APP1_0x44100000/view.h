

void initView();
void getRestoreString(char* input);
void printOutPut(char* outPut);
void printInPut();
void clearView();
void reTranslationView();
