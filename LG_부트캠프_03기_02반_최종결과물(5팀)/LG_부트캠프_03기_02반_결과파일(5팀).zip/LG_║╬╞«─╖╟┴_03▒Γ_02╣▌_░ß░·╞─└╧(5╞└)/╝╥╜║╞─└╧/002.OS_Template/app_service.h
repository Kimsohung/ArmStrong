
#include "app_size.h"

int initApp(int appNum);
int setApp(int index);
int getCurAppNum(void);
int setCurAppNum(int num);
