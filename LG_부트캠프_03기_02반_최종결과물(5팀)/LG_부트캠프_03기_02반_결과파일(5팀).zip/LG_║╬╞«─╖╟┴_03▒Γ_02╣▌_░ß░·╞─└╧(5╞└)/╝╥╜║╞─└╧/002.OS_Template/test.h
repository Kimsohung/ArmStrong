
// print

void checkRegister(void);
void checkR0(unsigned int r0);

// test

void Print_Hello(void);
int _Sqr(int a);
long long _Long_Long_Add(long long a, long long b);
