
#include "app_service.h"

int initializeApp(int appNum);
int switchAppASIDTTBR();
