#include "Device_Driver.h"

int Main(void)
{
	Uart_Printf(">>APP0\n");

	return 0;
}
