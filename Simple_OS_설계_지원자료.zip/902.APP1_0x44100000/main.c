#include "Device_Driver.h"

int Main(void)
{
	Uart_Printf(">>APP1, RO-BASE = 0x44100000\n");

	return 0;
}
